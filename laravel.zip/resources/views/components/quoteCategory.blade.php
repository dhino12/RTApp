<span class="material-symbols-outlined text-3xl px-3 py-2 rounded-2xl shadow-lg bg-gradient-to-r from-cyan-400 to-blue-600 text-white">
    list_alt
</span>
<h1 class="font-bold md:text-2xl text-xl mx-auto my-5">
    Jelajahi Kegiatan Berdasarkan Kategori
</h1>
<p>Jelajahi ragam kategori, temukan kegembiraan dan cerita tak terlupakan di setiap halaman. 🌈📚 #EksplorasiKategori</p>