

<?php $__env->startSection('header'); ?>
    <div class="w-full">
        <div
            class="absolute -z-10 w-full top-0 bg-gradient-to-b from-[#141727] to-[#3a416f] h-96 overflow-hidden"
        >
            <div class="h-72"></div>
        </div>
        <?php echo $__env->make('components/navbar', [
            "className" => "container mt-5 mx-auto p-4 px-10 fill-white sm:px-[20vh] flex flex-col justify-between text-slate-200 transition-all duration-200 lg:flex-row lg:items-center"
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="">
    <img
        src="https://source.unsplash.com/1000x600?indonesia"
        alt=""
        class="mx-auto h-[65vh] w-4/5 mt-5 rounded-3xl overflow-hidden object-cover object-center"
    />

    <div class="text-center mt-8 mx-10 sm:w-2/4 sm:mx-auto">
        <h4 class="font-semibold text-lg text-blue-600">
            <a href="/gallery?category=<?php echo e($gallery->category->slug); ?>"><?php echo e($gallery->category->title); ?></a>
        </h4>
        <h1 class="text-3xl font-bold capitalize my-3 bg-gradient-to-l from-cyan-400 to-blue-600 bg-clip-text text-transparent">
            <?php echo e($gallery->title); ?>

        </h1>
        <div class="flex mx-auto justify-center gap-5 mb-3">
            <p>By: 
                <b><a href="/gallery?author=<?php echo e($gallery->author->username); ?>"><?php echo e($gallery->author->name); ?></a></b>, 
            </p>
            <p class="font-medium"><?php echo e($gallery->created_at->diffForHumans()); ?></p>
        </div>
        <p class="text-justify font-inter">
            <?php echo $gallery->body; ?>

        </p>
    </div>

    <div class="p-5 sm:p-8  mx-auto">
        <div class="columns-1 gap-5 sm:columns-1 md:columns-2 sm:gap-8 lg:columns-2 2xl:columns-3 [&>img:not(:first-child)]:mt-8">
            <?php $__currentLoopData = $gallery->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="">
                    <div class="mb-4 rounded-lg overflow-hidden card-hover shadow-md shadow-gray-400 relative">
                        <img src="<?php echo e($image->name); ?>" class="h-full w-full object-cover object-center"/>
                        <div class="absolute bottom-0 bg-gradient-to-b from-slate-400/10 to-slate-900/80 w-full min-h-20 p-4 text-white">
                            <h2 class="font-bold text-xl">
                                <?php echo e($image->title); ?>

                            </h2>
                            <p class="line-clamp-2">
                                <?php echo e($image->description); ?>

                            </p>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('components/footer-landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\RTApp\resources\views/galleryDetail.blade.php ENDPATH**/ ?>