

<?php $__env->startSection('container'); ?>
<div class="w-full px-6 py-6 mx-auto">
    
    <!-- breadcrumb -->
    <?php echo $__env->make('dashboard/components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- cards row 4 -->
    <div class="flex flex-col -mx-3 gap-5">
        <div class="flex-1 px-5 md:w-2/3 mx-auto mt-5"> 
            <div id="profile" class="flex flex-col gap-5 p-5 mb-8 bg-white shadow-xl shadow-slate-100 rounded-xl">
                <h1 class="font-bold text-xl tracking-normal">Delete Category: <?php echo e($post->title); ?></h1>
                <p>Sebelum delete, perlu diperhatikan ada beberapa postingan yang terkait dengan category ini</p>
                <div class="bg-orange-200 border border-orange-400 text-green-800 px-4 py-3 rounded relative mb-5" role="alert">
                    <strong class="font-bold">Peringatan: </strong>
                    <p>Pastikan sudah memindahkan semua postingan terkait dengan categori ini, ke categori lainnya</p>
                </div>
                <?php if(session()->has('error')): ?>
                    <div class="bg-red-100 border border-red-400 text-red-800 px-4 py-3 rounded relative mb-5" role="alert">
                        <strong class="font-bold">Failed: </strong>
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(Request::getRequestUri()); ?>" method="post" class="inline-block">
                    <?php echo method_field("delete"); ?>
                    <?php echo csrf_field(); ?>
                    <span class="w-full">
                        <label for="body" class="block font-bold text-black text-sm">Yakin Delete ?</label>
                        <?php if(count($gallery) != 0 || count($blogs) != 0): ?>
                        <button 
                            class="my-2 bg-gradient-to-tl from-gray-600 to-black-400 px-2.5 text-sm rounded-1.8 py-1.4 inline-block whitespace-nowrap text-center align-baseline font-bold uppercase leading-none text-white transition-all active:scale-[0.95] hover:scale-[1.05]"
                            onclick="return confirm('yakin delete ?')"
                            disabled
                        >
                            Delete
                        </button>
                        <?php else: ?>
                        <button
                            class="my-2 bg-gradient-to-tl from-red-600 to-red-400 px-2.5 text-sm rounded-1.8 py-1.4 inline-block whitespace-nowrap text-center align-baseline font-bold uppercase leading-none text-white transition-all active:scale-[0.95] hover:scale-[1.05]"
                            onclick="return confirm('yakin delete ?')"
                        >
                            Delete
                        </button>
                        <?php endif; ?>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <a href="/dashboard/categories" class="my-2 bg-gradient-to-tl from-gray-600 to-black-400 px-2.5 text-sm rounded-1.8 py-1.4 inline-block whitespace-nowrap text-center align-baseline font-bold uppercase leading-none text-white transition-all active:scale-[0.95] hover:scale-[1.05]">
                            Cancle
                        </a>
                    </span>
                </form>
            </div>
        </div>
        <div class="relative flex flex-col min-w-0 mb-6 break-words bg-white border-0 border-transparent border-solid shadow-soft-xl rounded-2xl bg-clip-border">
            <div class="p-6 pb-0 mb-0 bg-white border-b-0 border-b-solid rounded-t-2xl border-b-transparent">
                <h6 class="font-bold">Blogs Table</h6>
            </div>
            <div class="flex-auto px-0 pt-0 pb-2">
                <?php echo $__env->make('dashboard/components/table', [
                    "theads" => ["Author", "Title", "Category", "Dibuat"],
                    "posts" => $blogs,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <div class="relative flex flex-col min-w-0 mb-6 break-words bg-white border-0 border-transparent border-solid shadow-soft-xl rounded-2xl bg-clip-border">
            <div class="p-6 pb-0 mb-0 bg-white border-b-0 border-b-solid rounded-t-2xl border-b-transparent">
                <h6 class="font-bold">Gallery Table</h6>
            </div>
            <div class="flex-auto px-0 pt-0 pb-2">
                <?php echo $__env->make('dashboard/components/table', [
                    "theads" => ["Author", "Title", "Category", "Dibuat"],
                    "posts" => $gallery,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function previewImage() {
        const image = document.querySelector("#image");
        const imgPreview = document.querySelector(".img-preview");

        imgPreview.style.display = "block";
        const offReader = new FileReader();
        offReader.readAsDataURL(image.files[0]);

        offReader.onload = function (oFREvent) {
            imgPreview.src = oFREvent.target.result;
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\RTApp\resources\views//dashboard/pages/form-delete-category.blade.php ENDPATH**/ ?>