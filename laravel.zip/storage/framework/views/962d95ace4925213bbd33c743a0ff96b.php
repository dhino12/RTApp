<?php
    $pattern = '/&quot;url&quot;:&quot;([^&]*)&quot;/';
    preg_match($pattern, $data->body, $bodyImageMatch);
    $bodyImageMatch = count($bodyImageMatch) == 0 ? 
        'https://source.unsplash.com/1000x600?football' : $bodyImageMatch[1];

    $galleryImages = count($data->images) == 0 || preg_match('/\.mp4$/', $data->images[0]->name) ? 
        false : '/images/' . $data->images[0]->name;
        
    $image = $galleryImages ?: $bodyImageMatch;
?>
<a href="/post/gallery/<?php echo e($data->slug); ?>" class="<?php echo e($className ?? ''); ?> block relative card-hover rounded-2xl overflow-hidden md:min-h-[50vh]">
    <div class="bg-gradient-to-b from-slate-400 to-slate-900 h-96 md:h-full">
        <img src="<?php echo e($image); ?>" alt="" class="mix-blend-overlay w-full h-full object-cover">
    </div>
    <div class="absolute bottom-0 mb-5 mx-5 text-white">
        <h2 class="text-2xl font-afacad font-semibold mb-4 line-clamp-2"><?php echo e($data->title); ?></h2>
        <p class="line-clamp-2"><?php echo e(strip_tags($data->body)); ?></p>
    </div>
</a><?php /**PATH D:\xampp\htdocs\RTApp\resources\views/components/card-image.blade.php ENDPATH**/ ?>