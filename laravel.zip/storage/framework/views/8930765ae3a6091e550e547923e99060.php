

<?php $__env->startSection('container'); ?>
<div class="w-full py-6 mx-auto">
    
    <!-- breadcrumb -->
    <div class="px-6">
        <?php echo $__env->make('dashboard/components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- cards row 4 -->
    <div class="mx-10 px-6 py-7 my-10 shadow-soft-sm lg:w-9/12 mx-10 lg:mx-auto rounded-xl bg-white">
        <div class="bg-orange-200 border border-orange-400 text-green-800 px-4 py-3 rounded relative mb-5" role="alert">
            <strong class="font-bold">Peringatan: </strong>
            <p>Ketika menghapus file didalam text-editor maka file tersebut akan terhapus dari sistem</p>
        </div>
        <?php if(session()->has('success')): ?>
            <div class="bg-lime-100 border border-green-400 text-green-800 px-4 py-3 rounded relative mb-5" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <h1 class="text-xl font-bold font-sans-serif capitalize">Edit <?php echo e(request()->segment(2)); ?></h1>
        <p>Form Edit <?php echo e(request()->segment(2)); ?></p>
        <form action="<?php echo e(str_replace('/edit', '', Request::getRequestUri())); ?>" method="post" enctype="multipart/form-data" class="flex justify-center flex-col my-5 gap-5 w-full">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="flex gap-5">
                <div class="w-full">
                    <label for="title" class="font-semibold">Title <span class="text-red-500 font-bold">*</span></label>
                    <input 
                        type="text" 
                        name="title" 
                        id="title" 
                        class="w-full mt-2 rounded-md h-10 px-2 py-2 border-2 border-slate-200 block text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-sky-500 focus:border-sky-500 invalid:text-red-500 invalid:focus:ring-red-700 invalid:focus:border-red-700 peer" 
                        placeholder="Judul"
                        required
                        value="<?php echo e(old('title', $post->title)); ?>"
                    >
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-500 font-bold">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input 
                        type="text" 
                        name="slug" 
                        id="slug" 
                        class="w-full invisible"
                        value="<?php echo e(old('slug', $post->slug)); ?>"
                        placeholder="Slug" 
                        alt="slug"
                        required 
                        readonly
                    >
                    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-500 font-bold">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div>
                <label for="category_id" class="font-semibold">Category <span class="text-red-500 font-bold">*</label>
                <span class="text-red-500 block">Tolong isikan category, agar postingan rapih terkelompok</span>
                <select name="category_id" id="category_id" class="w-full choice" placeholder="Category" required>
                    <?php if(old('category_id') == $post->category->id): ?>
                        <option value="<?php echo e($post->category->id); ?>" selected><?php echo e($post->category->title); ?></option>
                    <?php endif; ?>
                </select>
                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 font-bold">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="body" class="font-semibold">Description</label>
                <input
                    type="hidden"
                    name="body" 
                    id="body" 
                    placeholder="masukan konten deskripsi"
                    value="<?php echo e(old('body', $post->body)); ?>"
                    class="w-full mt-2 rounded-md h-10 px-2 py-2 border-2 border-slate-200 block text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-sky-500 focus:border-sky-500 invalid:text-red-500 invalid:focus:ring-red-700 invalid:focus:border-red-700 peer"
                >
                <trix-editor input="body" placeholder="masukan konten deskripsi"></trix-editor>
                <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 font-bold">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="images" class="font-semibold">Gambar Files</label>
                <div class="text-red-500 text-sm font-semibold">
                    Max file upload: <b>50MB</b>
                </div>
                <input
                    type="file" 
                    class="filepond"
                    name="images"
                    multiple
                >
            </div>
            <div class="flex gap-5 flex-col md:flex-row items-center mt-10 w-full">
                <a href="/dashboard/<?php echo e(request()->segment(2)); ?>"class="bg-slate-200 px-7 py-2 rounded-lg font-semibold shadow-soft-xs active:scale-[0.95] hover:scale-[1.05] transition-all lg:mt-0">
                    Batal
                </a>
                <button type="submit" id="submit" class="capitalize bg-gradient-to-l from-cyan-400 to-blue-600 px-4 py-2 rounded-lg font-semibold text-white active:scale-[0.95] hover:scale-[1.05] transition-all lg:mt-0">
                    Edit <?php echo e(request()->segment(2)); ?>

                </button>
            </div>
        </form>
    </div>

    <!-- Card Image  -->
    <div class="mt-10 mx-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="relative">
            <div class="absolute top-3 right-3 z-10">
                <button data-action="edit" class="bg-gradient-to-tl from-green-600 to-lime-400 px-2.5 text-sm rounded-1.8 py-1.4 font-bold uppercase text-white transition-all active:scale-[0.95] hover:scale-[1.05] hover:cursor-pointer">
                    Edit
                </button>
                <form action="/delete-file?id=<?php echo e($image->id); ?>" method="POST" class="inline-block">
                    <?php echo method_field("delete"); ?>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($post->slug); ?>" name="slug">
                    <button onclick="return confirm('yakin delete ?')" class="bg-gradient-to-tl from-red-600 to-red-400 px-2.5 text-sm rounded-1.8 py-1.4 font-bold uppercase text-white transition-all active:scale-[0.95] hover:scale-[1.05] hover:cursor-pointer">
                        Delete
                    </button>
                </form>
            </div>
            <div class="bg-gradient-to-b from-slate-400 to-slate-900 h-96 md:h-full card-hover rounded-2xl overflow-hidden sm:bg-red-200 md:min-h-[50vh] shadow-lg shadow-slate-300">
                <embed src="/images/<?php echo e($image->name); ?>" autoplay=0 alt="" class="mix-blend-overlay w-full h-full object-cover">
            </div>
            <div class="absolute bottom-0 mb-5 mx-5">
                <h2 class="text-2xl text-white font-sans-serif font-semibold mb-4 line-clamp-2"><?php echo e($image->title); ?>.</h2>
                <p class="text-white line-clamp-2"><?php echo e(strip_tags($image->description)); ?></p>
            </div> 

            <!-- Modal  -->
            <div class="relative z-20 invisible" aria-labelledby="modal-title" role="dialog" aria-modal="true">
                <div class="fixed h-screen w-screen inset-0 bg-gray-500 bg-opacity-75 transition-opacity" data-action="cancle"></div>
            
                <div class="fixed inset-0 z-60 w-screen overflow-y-auto">
                    <div class="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
                        <div class="transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-fit">
                            <div class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                                <div class="sm:flex sm:items-start">
                                    <div class="mx-auto flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full bg-lime-100 sm:mx-0 sm:h-10 sm:w-10">
                                        <span class="material-symbols-outlined">
                                            mms
                                        </span>
                                    </div>
                                    <div class="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
                                        <h3 class="text-base font-semibold leading-6 text-gray-900" id="modal-title">Deskripsi Gambar</h3>
                                        <div class="mt-2">
                                            <form action="/update-file?id=<?php echo e($image->id); ?>" method="post" class="w-full">
                                                <?php echo method_field("put"); ?>
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e($post->slug); ?>" name="slug">
                                                <div class="mb-5">
                                                    <label for="body">Judul</label>
                                                    <input 
                                                        type="text" 
                                                        name="title" 
                                                        id="title" 
                                                        class="w-full mt-2 rounded-md h-10 px-2 py-2 border-2 border-slate-200 block text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-sky-500 focus:border-sky-500 invalid:text-red-500 invalid:focus:ring-red-700 invalid:focus:border-red-700 peer" 
                                                        placeholder="Judul"
                                                        required
                                                        value="<?php echo e(old('title', $image->title)); ?>"
                                                    >
                                                </div>
                                                <div>
                                                    <label for="body">Description</label>
                                                    <textarea
                                                        type="text"
                                                        name="description"
                                                        id="description" 
                                                        placeholder="masukan konten deskripsi"
                                                        class="w-full mt-2 rounded-md h-10 px-2 py-2 border-2 border-slate-200 block text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-sky-500 focus:border-sky-500 invalid:text-red-500 invalid:focus:ring-red-700 invalid:focus:border-red-700 peer"
                                                    ><?php echo e(old('description', $image->description)); ?></textarea>
                                                    
                                                </div>
                                                <div class="mx-auto mt-10 w-fit">
                                                    <button type="reset" data-action="cancel" class="bg-slate-200 px-7 py-2 rounded-lg font-semibold shadow-soft-xs mt-3 active:scale-[0.95] hover:scale-[1.05] transition-all lg:mt-0 mx-5">
                                                        Batal
                                                    </button>
                                                    <button type="submit" id="submit" class="capitalize bg-gradient-to-l from-cyan-400 to-blue-600 px-4 py-2 rounded-lg font-semibold text-white mt-3 active:scale-[0.95] hover:scale-[1.05] transition-all lg:mt-0">
                                                        Edit <?php echo e(request()->segment(2)); ?>

                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- Drag & Drop Files Config  -->
<script src="https://unpkg.com/filepond-plugin-image-preview/dist/filepond-plugin-image-preview.js"></script>
<script src="https://unpkg.com/filepond-plugin-file-validate-size/dist/filepond-plugin-file-validate-size.js"></script>
<script src="https://unpkg.com/filepond@^4/dist/filepond.js"></script>
<script src="https://unpkg.com/filepond-plugin-file-validate-type/dist/filepond-plugin-file-validate-type.js"></script>
<script src="/js/attachmentTrixEditor.js"></script>
<script> 
    function getCategories() {
        const categories = fetch(`http://127.0.0.1:8000/api/categories`)
            .then(response => response.json())
            .then(dataArray => {
                const element = document.querySelector('.choice');
                const choices = new Choices(element, {
                    removeItems: true,
                    removeItemButton: true,
                    placeholder: true,
                    maxItemCount: 1,
                    items: ['hello', 'world'],
                    choices: dataArray.map(item => ({ value: item.id, label: item.title })),
                    searchPlaceholderValue: "Cari kategori disini",
                    allowHTML: false,
                    sorter: (a,b) => {},
                    addItemText: (value) => {
                        if (dataArray.includes(value)) {
                            // Jika ada, izinkan penambahan
                            return `Tekan enter untuk tambah <b>"${value}"</b>`;
                        } else {
                            // Jika tidak ada, berikan pesan kustom
                            return `Hanya dapat memilih dari opsi yang ada`;
                        }
                    },
                    placeholderValue: 'Isikan kategori',
                    classNames: { 
                        containerInner: 'border-2',
                    }
                });
            })
            .catch(error => console.error(error));
        return categories;
    }
    getCategories()

    window.addEventListener('beforeunload', function (event) {
        return confirmationMessage;
    });
    
    window.addEventListener('load', function (event) {
        // delete tmp
        fetch('/delete-tmp', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
            },
            body: JSON.stringify({
                username: '<?php echo e(auth()->user()->username); ?>'
            })
        })
            .then(response => response.json())
            .then(data => console.log(data))
    });
</script>
<script>
    // We want to preview images, so we register
    FilePond.registerPlugin(
        FilePondPluginImagePreview,
        FilePondPluginFileValidateSize,
        FilePondPluginFileValidateType
    );

    // create() to turn it into a pond
    const inputElement = document.querySelector('input[type="file"]');
    const pond = FilePond.create(inputElement, {
        allowFileSizeValidation: true,
        labelMaxFileSizeExceeded: 'File terlalu besar',
        maxFileSize: '50MB',
        acceptedFileTypes: ['image/png',"image/gif","image/jpeg", 'video/mp4'],
    });
    FilePond.setOptions({
        server: {
            process: '/upload',
            revert: '/delete',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            }
        }
    })

    // How to use with Pintura Image Editor:
    // https://pqina.nl/pintura/docs/latest/getting-started/installation/filepond/
</script>
<script>
    const title = document.querySelector('#title');
    const slug = document.querySelector('#slug');

    title.addEventListener('change', function() {
        fetch('/api/blogs/checkSlug?title=' + title.value)
            .then(response => response.json())
            .then(data => slug.value = data.slug)
    })
</script>
<script> 
    const actionButtons = document.querySelectorAll('[data-action]');
    function toggleModalVisibility(modal) {
        modal.classList.toggle("invisible");
    }
    function handleButtonClick(event) {
        const action = event.target.dataset.action;
        const modal = event.target.closest('.relative');
        console.log(action);
        if (action === 'edit') {
            toggleModalVisibility(modal.querySelector('[role="dialog"]'));
        }
        if (action === 'cancel') {
            toggleModalVisibility(modal)
        }
    }

    document.body.addEventListener('click', function (event) {
        if (event.target.matches('[data-action]')) {
            handleButtonClick(event);
        }
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\RTApp\resources\views//dashboard/pages/form-edit.blade.php ENDPATH**/ ?>